================================================================
  ZAWOJA SYSTEM - FULL AUTO-INSTALLER
  Installs EVERYTHING automatically - including Node.js!
================================================================

WHAT IT DOES:
-------------
ONE script installs EVERYTHING from zero:
  - Downloads and installs Node.js (if not installed)
  - Creates React + TypeScript project
  - Installs Firebase SDK
  - Installs all dependencies (Leaflet, Lucide, Tailwind)
  - Configures everything
  - Copies application files
  - Creates ready-to-run project

NO manual downloads needed!
NO prerequisites needed!
Just run the script!


INSTALLATION STEPS:
-------------------

STEP 1: Run install.ps1
  - Right-click install.ps1 -> "Run with PowerShell"
  - Click "Yes" when asked for Administrator rights

STEP 2: If Node.js is NOT installed:
  - Script will download and install Node.js automatically
  - Script will say: "NODE.JS INSTALLED - RESTART REQUIRED"
  - Close the window
  - Run install.ps1 AGAIN (second time)
  
  If Node.js IS already installed:
  - Script continues directly to installation
  - No restart needed

STEP 3: Wait 10-15 minutes
  - Script installs everything automatically
  - You can see progress: [1/11], [2/11], etc.

STEP 4: Configure Firebase (2 minutes)
  - See "AFTER INSTALLATION" section below

Done!


WHY TWO RUNS IF NO NODE.JS?
----------------------------
When Node.js is installed for the first time, PowerShell 
needs to restart to recognize it. This is normal Windows 
behavior. Just run the script twice:
  First run:  Installs Node.js
  Second run: Installs everything else


WHAT HAPPENS DURING INSTALLATION:
----------------------------------

First run (if no Node.js):
  [1/11] Checking Node.js -> Downloads and installs
  -> "Please run install.ps1 AGAIN"
  -> Script exits

Second run (or first if Node.js exists):
  [1/11] Checking Node.js -> Already installed
  [2/11] Checking npm -> Fixed cache folders
  [3/11] Preparing -> Clean old files
  [4/11] Creating React project (5-10 min)
  [5/11] Installing Firebase
  [6/11] Installing dependencies
  [7/11] Configuring Tailwind CSS
  [8/11] Copying application files
  [9/11] Configuring Leaflet
  [10/11] Creating config files
  [11/11] Finalizing

Total time: 10-15 minutes (automatic)


AFTER INSTALLATION:
-------------------

Configure Firebase (2 minutes):

1. Go to: https://console.firebase.google.com
2. Create project -> Enable Firestore Database
3. Get config: Project Settings -> Web app
4. Edit: C:\Users\YourName\zawoja-system\src\firebase.ts
5. Replace YOUR_API_KEY_HERE with your values

Run application:

  cd C:\Users\YourName\zawoja-system
  npm start

Or click: C:\Users\YourName\zawoja-system\start.bat

App opens at: http://localhost:3000


FIRST LOGIN:
------------
  Username: admin
  Password: admin123


FILES IN PACKAGE:
-----------------
  install.ps1                    - Auto-installer (RUN THIS!)
  App-NewLayout-Firebase.tsx     - Application code
  firebase.ts                    - Firebase config
  README-AUTO.txt                - This file


REQUIREMENTS:
-------------
  - Windows 10/11
  - Internet connection
  - Administrator rights (script asks automatically)

That's it! No Node.js needed - script installs it!


TROUBLESHOOTING:
----------------

Problem: "npm not found" or "no such file or directory"
Solution: This happens if you ran script only ONCE after Node.js 
         installation. Run install.ps1 AGAIN (second time).

Problem: "Script cannot be loaded"
Solution: Right-click install.ps1 -> "Run with PowerShell"

Problem: Script hangs at "Creating React project"
Solution: Wait - this step takes 5-10 minutes

Problem: "Node.js installation failed"
Solution: Download manually from nodejs.org and run script again


QUICK START SUMMARY:
--------------------

1. Extract ZIP
2. Right-click install.ps1 -> Run with PowerShell
3. If script says "restart required" -> Run install.ps1 again
4. Wait 10-15 minutes
5. Configure Firebase
6. Run: npm start
7. Login: admin / admin123
8. Done!


================================================================
  READY TO GO!
  Right-click install.ps1 -> Run with PowerShell
================================================================
