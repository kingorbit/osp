# ZAWOJA SYSTEM - FULL AUTO INSTALLER
# Automatically downloads and installs EVERYTHING including Node.js

# Require Administrator rights
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "This script requires Administrator rights." -ForegroundColor Red
    Write-Host "Restarting as Administrator..." -ForegroundColor Yellow
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$ErrorActionPreference = "Stop"
$projectName = "zawoja-system"
$projectDir = "$env:USERPROFILE\$projectName"

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  ZAWOJA SYSTEM - FULL AUTO INSTALLER" -ForegroundColor Cyan
Write-Host "  Everything from zero - including Node.js!" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# ============================================
# STEP 1: Check and install Node.js
# ============================================

Write-Host "[1/11] Checking Node.js..." -ForegroundColor Yellow

$nodeInstalled = $false
$needsRestart = $false

try {
    $null = Get-Command node -ErrorAction Stop
    $nodeVersion = node --version
    Write-Host "OK: Node.js already installed: $nodeVersion" -ForegroundColor Green
    $nodeInstalled = $true
} catch {
    Write-Host "Node.js not found. Installing automatically..." -ForegroundColor Yellow
    
    # Download Node.js installer
    $nodeVersion = "20.11.0"
    $nodeUrl = "https://nodejs.org/dist/v$nodeVersion/node-v$nodeVersion-x64.msi"
    $installerPath = "$env:TEMP\nodejs-installer.msi"
    
    Write-Host "Downloading Node.js v$nodeVersion..." -ForegroundColor Yellow
    try {
        Invoke-WebRequest -Uri $nodeUrl -OutFile $installerPath -UseBasicParsing
        Write-Host "OK: Node.js downloaded" -ForegroundColor Green
    } catch {
        Write-Host "ERROR: Failed to download Node.js" -ForegroundColor Red
        Write-Host "Please download manually from: https://nodejs.org" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
    
    # Install Node.js silently
    Write-Host "Installing Node.js (this takes 2-3 minutes)..." -ForegroundColor Yellow
    $installArgs = "/i `"$installerPath`" /quiet /norestart"
    Start-Process "msiexec.exe" -ArgumentList $installArgs -Wait -NoNewWindow
    
    # Clean up installer
    Remove-Item $installerPath -Force
    
    Write-Host "OK: Node.js installed!" -ForegroundColor Green
    $needsRestart = $true
}

# If Node.js was just installed, need to restart script
if ($needsRestart) {
    Write-Host ""
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host "  NODE.JS INSTALLED - RESTART REQUIRED" -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Node.js has been installed successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Please CLOSE this window and run install.ps1 AGAIN" -ForegroundColor Yellow
    Write-Host "to continue with the installation." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Why? Node.js needs a fresh PowerShell session to work." -ForegroundColor Gray
    Write-Host ""
    Read-Host "Press Enter to close this window"
    exit 0
}

# ============================================
# STEP 2: Verify npm and fix cache
# ============================================

Write-Host ""
Write-Host "[2/11] Checking npm..." -ForegroundColor Yellow

# Fix npm cache folders
$npmCache = "$env:APPDATA\npm-cache"
$npmPrefix = "$env:APPDATA\npm"

if (-not (Test-Path $npmCache)) {
    New-Item -ItemType Directory -Path $npmCache -Force | Out-Null
    Write-Host "Created npm cache folder" -ForegroundColor Gray
}

if (-not (Test-Path $npmPrefix)) {
    New-Item -ItemType Directory -Path $npmPrefix -Force | Out-Null
    Write-Host "Created npm prefix folder" -ForegroundColor Gray
}

# Configure npm
npm config set cache "$npmCache" --global
npm config set prefix "$npmPrefix" --global

try {
    $npmVersion = npm --version
    Write-Host "OK: npm $npmVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: npm not found" -ForegroundColor Red
    Write-Host "Please restart PowerShell and try again" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# ============================================
# STEP 3: Remove old project
# ============================================

Write-Host ""
Write-Host "[3/11] Preparing..." -ForegroundColor Yellow

if (Test-Path $projectDir) {
    Write-Host "Removing old project..." -ForegroundColor Yellow
    Remove-Item $projectDir -Recurse -Force
    Write-Host "OK: Old project removed" -ForegroundColor Green
}

# ============================================
# STEP 4: Create React project
# ============================================

Write-Host ""
Write-Host "[4/11] Creating React TypeScript project..." -ForegroundColor Yellow
Write-Host "This takes 5-10 minutes..." -ForegroundColor Gray
Write-Host ""

try {
    npx create-react-app@latest $projectDir --template typescript --use-npm
    
    if (-not (Test-Path $projectDir)) {
        Write-Host "ERROR: Failed to create project" -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }
    
    Write-Host "OK: React project created" -ForegroundColor Green
    Set-Location $projectDir
} catch {
    Write-Host "ERROR: Failed to create React project" -ForegroundColor Red
    Write-Host "Error: $_" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# ============================================
# STEP 5: Install Firebase
# ============================================

Write-Host ""
Write-Host "[5/11] Installing Firebase SDK..." -ForegroundColor Yellow
npm install firebase
Write-Host "OK: Firebase installed" -ForegroundColor Green

# ============================================
# STEP 6: Install dependencies
# ============================================

Write-Host ""
Write-Host "[6/11] Installing dependencies..." -ForegroundColor Yellow
npm install lucide-react leaflet
npm install -D @types/leaflet tailwindcss@3.3.0 postcss@8.4.31 autoprefixer@10.4.16
Write-Host "OK: All dependencies installed" -ForegroundColor Green

# ============================================
# STEP 7: Configure Tailwind
# ============================================

Write-Host ""
Write-Host "[7/11] Configuring Tailwind CSS..." -ForegroundColor Yellow
npx tailwindcss init

"module.exports={content:['./src/**/*.{js,jsx,ts,tsx}'],theme:{extend:{}},plugins:[]}" | Out-File tailwind.config.js -Encoding UTF8
"module.exports={plugins:{tailwindcss:{},autoprefixer:{}}}" | Out-File postcss.config.js -Encoding UTF8
"@tailwind base;`n@tailwind components;`n@tailwind utilities;" | Out-File src\index.css -Encoding UTF8
Write-Host "OK: Tailwind configured" -ForegroundColor Green

# ============================================
# STEP 8: Copy application files
# ============================================

Write-Host ""
Write-Host "[8/11] Copying application files..." -ForegroundColor Yellow

$scriptDir = Split-Path -Parent $PSCommandPath
$firebaseSource = Join-Path $scriptDir "firebase.ts"
$appSource = Join-Path $scriptDir "App-NewLayout-Firebase.tsx"

if (Test-Path $firebaseSource) {
    Copy-Item $firebaseSource "src\firebase.ts" -Force
    Write-Host "OK: firebase.ts copied" -ForegroundColor Green
} else {
    Write-Host "WARNING: firebase.ts not found" -ForegroundColor Yellow
}

if (Test-Path $appSource) {
    Copy-Item $appSource "src\App.tsx" -Force
    Write-Host "OK: App.tsx copied" -ForegroundColor Green
} else {
    Write-Host "WARNING: App-NewLayout-Firebase.tsx not found" -ForegroundColor Yellow
}

# ============================================
# STEP 9: Configure Leaflet
# ============================================

Write-Host ""
Write-Host "[9/11] Configuring Leaflet..." -ForegroundColor Yellow

$html = Get-Content "public\index.html" -Raw
if ($html -notmatch 'leaflet.css') {
    $html = $html -replace '</head>', "    <link rel=`"stylesheet`" href=`"https://unpkg.com/leaflet@1.9.4/dist/leaflet.css`" />`n    <script src=`"https://unpkg.com/leaflet@1.9.4/dist/leaflet.js`"></script>`n  </head>"
    Set-Content "public\index.html" -Value $html -Encoding UTF8
}
Write-Host "OK: Leaflet configured" -ForegroundColor Green

# ============================================
# STEP 10: Create configuration files
# ============================================

Write-Host ""
Write-Host "[10/11] Creating configuration files..." -ForegroundColor Yellow

"GENERATE_SOURCEMAP=false`nNODE_OPTIONS=--max_old_space_size=4096" | Out-File .env -Encoding UTF8
"@echo off`ncd /d `"$projectDir`"`nnpm start" | Out-File start.bat -Encoding UTF8

Write-Host "OK: Configuration files created" -ForegroundColor Green

# ============================================
# STEP 11: Final setup
# ============================================

Write-Host ""
Write-Host "[11/11] Finalizing..." -ForegroundColor Yellow
Write-Host "OK: Installation complete!" -ForegroundColor Green

# ============================================
# SUMMARY
# ============================================

Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host "  INSTALLATION SUCCESSFUL!" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host ""

Write-Host "Installed:" -ForegroundColor Cyan
Write-Host "  - React + TypeScript" -ForegroundColor White
Write-Host "  - Firebase SDK" -ForegroundColor White
Write-Host "  - Leaflet (maps)" -ForegroundColor White
Write-Host "  - Lucide React (icons)" -ForegroundColor White
Write-Host "  - Tailwind CSS" -ForegroundColor White
Write-Host "  - Application with new layout" -ForegroundColor White
Write-Host ""

Write-Host "Project location:" -ForegroundColor Cyan
Write-Host "  $projectDir" -ForegroundColor White
Write-Host ""

Write-Host "========================================================" -ForegroundColor Yellow
Write-Host "  CONFIGURE FIREBASE (2 minutes)" -ForegroundColor Yellow
Write-Host "========================================================" -ForegroundColor Yellow
Write-Host ""

Write-Host "1. Go to: https://console.firebase.google.com" -ForegroundColor White
Write-Host "2. Create project -> Enable Firestore" -ForegroundColor White
Write-Host "3. Get config (Project Settings -> Web app)" -ForegroundColor White
Write-Host "4. Edit: $projectDir\src\firebase.ts" -ForegroundColor Cyan
Write-Host "5. Replace YOUR_API_KEY_HERE with your data" -ForegroundColor White
Write-Host ""

Write-Host "Then run:" -ForegroundColor Yellow
Write-Host "  cd $projectDir" -ForegroundColor Cyan
Write-Host "  npm start" -ForegroundColor Cyan
Write-Host ""

$openFirebase = Read-Host "Open Firebase Console now? (Y/N)"
if ($openFirebase -eq "Y" -or $openFirebase -eq "y") {
    Start-Process "https://console.firebase.google.com"
}

$editConfig = Read-Host "Open firebase.ts for editing? (Y/N)"
if ($editConfig -eq "Y" -or $editConfig -eq "y") {
    Start-Process notepad "$projectDir\src\firebase.ts"
}

$openFolder = Read-Host "Open project folder? (Y/N)"
if ($openFolder -eq "Y" -or $openFolder -eq "y") {
    Start-Process explorer $projectDir
}

Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host "  Done! Configure Firebase and run: npm start" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host ""

Read-Host "Press Enter to exit"
